# notify_in_stock_plugin
Wordpress woocommerce plugin, allow customers to request to be notified when an item is back in stock
